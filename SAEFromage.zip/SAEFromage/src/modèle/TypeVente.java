package modèle;


public enum TypeVente {
A_LA_COUPE_AU_POIDS, A_L_UNITE, ENTIER_OU_MOITIE, A_L_UNITE_PlUSIEURS_CHOIX, POUR_X_PERSONNES
}
